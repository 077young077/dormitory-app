import type { Platform } from './types';
export declare const platform: Required<Platform>;
