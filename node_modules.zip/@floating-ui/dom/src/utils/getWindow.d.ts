export declare function getWindow(node: Node): Window;
