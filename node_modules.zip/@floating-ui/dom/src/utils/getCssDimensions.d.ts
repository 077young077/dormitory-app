import type { Dimensions } from '@floating-ui/core';
export declare function getCssDimensions(element: Element): Dimensions & {
    fallback: boolean;
};
