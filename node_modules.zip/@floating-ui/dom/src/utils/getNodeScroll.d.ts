import { NodeScroll } from '../types';
export declare function getNodeScroll(element: Element | Window): NodeScroll;
