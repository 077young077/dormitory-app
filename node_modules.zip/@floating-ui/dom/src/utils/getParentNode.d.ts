export declare function getParentNode(node: Node): Node;
