export declare function isNode(value: any): value is Node;
export declare function getNodeName(node: Node | Window): string;
