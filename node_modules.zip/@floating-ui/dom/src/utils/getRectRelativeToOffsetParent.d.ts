import type { Rect, Strategy, VirtualElement } from '@floating-ui/core';
export declare function getRectRelativeToOffsetParent(element: Element | VirtualElement, offsetParent: Element | Window, strategy: Strategy): Rect;
