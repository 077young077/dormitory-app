type OverflowAncestors = Array<Element | Window | VisualViewport>;
export declare function getOverflowAncestors(node: Node, list?: OverflowAncestors): OverflowAncestors;
export {};
