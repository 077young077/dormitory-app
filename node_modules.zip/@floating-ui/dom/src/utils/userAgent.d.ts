export declare function getUAString(): string;
