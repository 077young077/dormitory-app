export declare function getDocumentElement(node: Node | Window): HTMLElement;
