export declare function getNearestOverflowAncestor(node: Node): HTMLElement;
