import type { Placement, Side } from './types';
export declare const sides: Side[];
export declare const allPlacements: Placement[];
