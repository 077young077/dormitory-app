import type { Axis, Placement } from '../types';
export declare function getMainAxisFromPlacement(placement: Placement): Axis;
