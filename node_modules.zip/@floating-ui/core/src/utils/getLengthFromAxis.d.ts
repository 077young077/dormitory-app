import type { Axis, Length } from '../types';
export declare function getLengthFromAxis(axis: Axis): Length;
