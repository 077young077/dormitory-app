import type { Axis } from '../types';
export declare function getCrossAxis(axis: Axis): Axis;
