import type { Placement, Side } from '../types';
export declare function getSide(placement: Placement): Side;
