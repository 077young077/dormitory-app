export declare function getOppositePlacement<T extends string>(placement: T): T;
