import type { Placement } from '../types';
export declare function getExpandedPlacements(placement: Placement): Array<Placement>;
